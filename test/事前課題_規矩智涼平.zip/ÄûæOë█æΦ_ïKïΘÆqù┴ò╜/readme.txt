■遊び方
0.以下のファイルを同じディレクトリに保存
  ・Play.ts
  ・CatClass.ts
  ・CatInterface.ts
  ・OutputMethods.ts

1.ファイルを保存したディレクトリに移動し、以下のコマンドを実行しコンパイルする
  $ tsc Play.ts

2.以下のコマンド実行で開始
  $ node Play.js

3.質問に対して適切な数値を入力し、[Enter]で決定

■ゲームを終了したい場合
  [Ctrl] + [C] を同時入力
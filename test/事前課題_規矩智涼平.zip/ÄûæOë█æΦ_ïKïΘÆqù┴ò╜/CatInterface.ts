export interface CatInterface {
  id: number;
	name: string;
  hungerPoint: number;
  hungerCoefficient: number;
  monsterMode: boolean;
}